Public Goods Game Experiment
Experiment Overview
A two-player public goods game implemented using oTree. Each participant starts with an endowment of 150 points. Players decide how much to contribute to a public pool (0-150 points). The total contributions are multiplied by an efficiency factor of 1.5 and then divided equally between both players.

Installation and Running Steps
Requirements
Python 3.7 or higher

pip package manager

Installation
Create virtual environment (recommended)

bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
venv\Scripts\activate  # Windows
Install oTree

bash
pip install otree
Download and extract experiment files
Unzip the provided ZIP file to the current directory

Run the experiment

bash
otree devserver
Access the experiment
Open your browser and go to http://localhost:8000

Quick Start
bash
# One-step installation and running
pip install otree
unzip public_goods_2p.zip
cd public_goods_2p
otree devserver
Session Configuration
The experiment uses the following settings:

Players per group: 2

Number of rounds: 1

Endowment: 150 points

Multiplier: 1.5

Participation fee: 2.00 units

Experiment Procedure
Instructions page: Game rules and payoff calculation

Decision page: Participants choose contribution amount (0-150 points)

Results page: Shows individual contribution, partner's contribution, and final payoff

Interview phase: Collects participants' decision reasoning

File Structure
text
public_goods_2p/
├── __init__.py
├── _templates/
│   └── public_goods_2p/
│       ├── Instructions.html
│       ├── Contribution.html
│       └── Results.html
├── _builtin/
│   └── __init__.py
├── static/
├── tests/
│   └── __init__.py
└── models.py
Usage Instructions
Test Mode
bash
# Run test session
otree devserver --test
Production Deployment
bash
# Create production settings
otree zipserver
Data Export
After the experiment, CSV data can be exported from the admin interface.

Configurable Parameters
In settings.py, you can adjust:

SESSION_CONFIGS: Session configurations

PARTICIPANT_FEE: Participation fee

REAL_WORLD_CURRENCY_PER_POINT: Point conversion rate

Technical Support
If you encounter technical issues, please check:

Python version compatibility

oTree installation status

Port 8000 availability

Ethical Considerations
This experiment is for academic research purposes only. All data will be anonymized and handled in accordance with research ethics standards.

License
This project is for teaching and research purposes only.
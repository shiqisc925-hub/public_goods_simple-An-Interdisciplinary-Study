# Economist Analysis: Public Goods Game

## Equilibrium Concept

The appropriate equilibrium concept for this public goods game is the **pure-strategy Nash equilibrium** in a normal-form (strategic) game.

### Formal Definition
- Let $N = \{1, 2, \ldots, n\}$ be the set of players
- For each player $i \in N$, the strategy set is $S_i = [0, e_i]$, where $e_i > 0$ is their endowment
- A strategy profile is $g = (g_1, g_2, \ldots, g_n) \in S_1 \times \cdots \times S_n$
- The payoff function for player $i$ is:
  $$u_i(g) = e_i - g_i + \alpha \sum_{j=1}^n g_j$$
  where $\alpha \in (0,1)$ is the marginal return factor

A strategy profile $g^* = (g_1^*, \ldots, g_n^*)$ is a **pure-strategy Nash equilibrium** if for every player $i \in N$ and all alternative $g_i \in S_i$:
$$u_i(g_i^*, g_{-i}^*) \geq u_i(g_i, g_{-i}^*)$$

### Existence Theorem
If for each player $i$, the strategy set $S_i$ is nonempty, compact, and convex, and each payoff function $u_i(g)$ is continuous in all components of $g$ and quasi-concave in $g_i$, then there exists at least one pure-strategy Nash equilibrium.

**Reference:** Osborne, M. J., & Rubinstein, A. (1994). *A course in game theory*. MIT Press. (pp. 15, 19)

## Analytical Solution

### Equilibrium Characterization
In this game, the unique pure-strategy Nash equilibrium occurs when **every player contributes nothing** (0 points) to the public good. 

The reasoning is straightforward: if all other players contribute zero, any positive contribution by one player would cost her more privately than she gains through the public good (because the multiplier α < 1). Thus, the best response is zero contribution. This logic applies to every player, making the all-zero contribution profile the Nash equilibrium.

### Efficiency Analysis
- **Pareto efficiency**: The all-zero equilibrium is not Pareto efficient when α × n > 1. In such cases, there exists another outcome (everyone contributing a small positive amount) that would make everyone strictly better off.

- **Utilitarian welfare**: When αn > 1, the socially optimal outcome requires everyone contributing as much as possible, generating more total benefit than private cost. The zero-contribution equilibrium yields significantly less total welfare than this social optimum.

### Fairness Considerations
- **Equity of burden**: With equal endowments, fairness suggests equal sharing of contribution burden. The zero-equilibrium avoids any burden but also eliminates public good benefits.

- **Proportionality**: A fair distribution would provide each player with proportionate benefits from cooperation. The zero-equilibrium fails this criterion completely.

- **Envy-freeness**: With equal endowments, the zero-equilibrium is envy-free as everyone achieves identical outcomes. With unequal endowments, it remains envy-free in the minimal sense that each keeps their initial resources.

**Reference:** Osborne, M. J., & Rubinstein, A. (1994). *A course in game theory*. MIT Press. (pp. 8-12)

## Interpretation

The prediction of zero contributions represents a foundational result in game theory, derived from perfect rationality assumptions. However, this stark prediction primarily serves to highlight the tension between theoretical elegance and empirical reality.

The equilibrium's most notable feature is its **computational tractability**. Each player has a strictly dominant strategy (contributing zero), which can be identified through simple unilateral calculation. This places the equilibrium-finding problem in complexity class P, meaning it can be solved efficiently by rational agents or algorithms.

This simplicity contrasts sharply with general Nash equilibrium problems, which are typically PPAD-complete (Roughgarden, 2016) and computationally challenging. The public goods game thus serves as an exception that proves the rule: most strategic problems requiring coordination or lacking dominant strategies are computationally difficult for both humans and computers.

Consequently, the gap between theoretical prediction (zero contributions) and empirical evidence (positive contributions) cannot be attributed to computational barriers. Instead, it must be explained by the failure of the model's behavioral assumptions. The model excludes social preferences (altruism, inequality aversion), conditional cooperation, and bounded rationality—factors that are computationally simple to implement heuristically but lead to outcomes far from the Nash equilibrium.

The public goods game therefore serves not as a computational puzzle, but as a benchmark for measuring the impact of human sociality on strategic behavior.

## References

1. Osborne, M. J., & Rubinstein, A. (1994). *A course in game theory*. MIT Press.
2. Roughgarden, T. (2016). *Twenty lectures on algorithmic game theory*. Cambridge University Press.
3. Fehr, E., & Schmidt, K. M. (1999). A theory of fairness, competition, and cooperation. *The Quarterly Journal of Economics, 114*(3), 817–868.
4. McKelvey, R. D., & Palfrey, T. R. (1995). Quantal response equilibria for normal form games. *Games and Economic Behavior, 10*(1), 6–38.